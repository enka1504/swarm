"""
Swarm Subnet 124 — autonomous drone flight controller (miner submission).

This file is **standalone**: only NumPy/SciPy; no imports from the rest of the
repository. The simulator supplies a dict with ego ``state`` and a normalized
``depth`` image; :meth:`DroneFlightController.act` returns a 5-D control vector
per tick.

**High-level pipeline**

1. **State parsing** — Read position, velocity, roll/pitch/yaw, angular rates, and
   the offset from the drone to the *search area* from ``observation["state"]``.
2. **Depth geometry** — Project world rays to pixels, sample depth along look /
   velocity direction, detect close obstacles in a front patch, and infer a
   coarse "open-like" scene flag from median depth.
3. **Finite-state control** — ``state == 0``: fly waypoints toward the search
   volume; ``1``: search with detours / turns when blocked; ``3``: track the
   detected goal platform and command descent / touchdown.
4. **Goal detection** — Segment depth edges into connected components, filter by
   planarity and distance to the search center, and maintain a fused estimate
   (with optional motion tracking) until enough consistent detections trigger
   state 3.

**Public API (names fixed for the benchmark loader)**

- ``DroneFlightController.act(observation)`` → ``ndarray`` shape ``(5,)``
- ``DroneFlightController.reset()`` — clear all episode memory between seeds

All helper methods are private (leading ``_``); many were renamed for readability
(see each docstring).

**Selected private method renames (internal only)**

Examples: ``_get_current_position`` → ``_read_position_xyz``;
``_move3d`` → ``_velocity_command_toward_point``;
``_detect_goal_platform`` → ``_find_goal_platform_from_depth``;
``_direction_world_to_pixel`` → ``_project_world_direction_to_pixel``.
The full set follows the same pattern (verb + object) for search and navigation helpers.

"""

import numpy as np
from collections import deque
from scipy.ndimage import minimum_filter, maximum_filter

class DroneFlightController:
    """
    Three-state flight controller for the Swarm challenge.

    **States**

    - **0 — Transit:** Move from spawn toward the search area using
      :meth:`_waypoints_for_height_match` until the waypoint queue is cleared,
      then switch to state 1.
    - **1 — Search:** Visit pseudo-random or ring-pattern targets around
      ``search_area_center``; handle front obstacles via detour waypoints
      (:meth:`_detour_waypoint_from_obstacle_cc`) or yaw-in-place exploration.
    - **3 — Goal:** After repeated goal detections, approach using
      :meth:`_velocity_command_toward_point` variants, open-scene fine tuning via
      :meth:`_state3_open_approach_command`, and lost-goal recovery heuristics.

    Class attributes (ALL_CAPS) tune speeds, depth thresholds, and goal scoring;
    they are tuned for the benchmark rather than for real hardware.
    """
    # Movement / speed
    MAX_SPEED_M_S = 1
    ACCELERATION_M_S2 = 1.5
    DECELERATION_START_DISTANCE = 1.5
    AT_TARGET_TOLERANCE = 0.5
    AT_TARGET_SPEED_THRESHOLD = 0.5
    SIM_DT = 1.0 / 50.0
    MAX_VELOCITY_CHANGE_NORM_M_S = 1.0
    RISE_HEIGHT_M = 0
    HORIZONTAL_M = 1.2
    MAX_SAFE_ROLL_PITCH_RAD = 0.3
    ACCEL_SCALE_AT_HIGH_TILT = 0.7
    MAX_SAFE_ANGULAR_VEL_RAD_S = 0.2
    ACCEL_SCALE_AT_HIGH_ANG_VEL = 0.7
    YAW_FACE_DIRECTION_MIN_DISTANCE_M = 0.5
    MAX_APPROACH_ANGLE_RAD = 0.15
    SPEED_SCALE_AT_LARGE_ANGLE = 0.6
    # Search area
    SEARCH_AREA_RADIUS_X_M = 10.0
    SEARCH_AREA_RADIUS_Y_M = 10.0
    SEARCH_AREA_RADIUS_Z_M = 2.0
    # Camera / depth
    CAMERA_FOV_RAD = 0.5 * 3.141592
    FRONT_PATCH_ROWS = 3
    FRONT_PATCH_COLS = 3
    FRONT_PATCH_RADIUS_PX = 3
    FRONT_OBSTACLE_MIN_DEPTH_M = 5.0
    DETOUR_WAYPOINT_SMOOTHING_PREV_WEIGHT = 0.5
    DANGER_DISTANCE_M = 1
    STATE1_DANGER_STEPS_WINDOW = 20
    GOAL_PLATFORM_MAX_EXTENT_M = 0.8  # max distance from component mean to any pixel
    DETOUR_MIN_CLEAR_DISTANCE_PX = 5
    CLEAR_DIRECTION_MIN_DEPTH_M = 1.0
    # 1m height error interval when keeping height for open path
    MAX_VERTICAL_COMPONENT_HORIZONTAL = 1.0 / (2.0 ** 0.5)  # ~0.707, ~45°
    CLEAR_DIRECTION_MIN_MARGIN_M = 0.5
    # Goal detection
    DEPTH_EDGE_JUMP = 0.08
    DEPTH_SIMILARITY_THRESHOLD_M = 0.1
    DEPTH_RANGE_NEAR_M = 0.5
    DEPTH_RANGE_FAR_M = 20.0
    GOAL_PLATFORM_MAX_HEIGHT_DIFF_M = 0.5
    MIN_COMPONENT_SIZE = 4
    BAD_PIXEL_DEPTH_THRESHOLD_M = 0.5
    GOOD_PIXEL_WINDOW_SIZE = 5
    GOAL_AVERAGE_POSITION_DISTANCE_M = 3.0
    GOAL_NEAR_FIXED_DISTANCE_M = 2.0
    NEAR_GOAL_DEPTH_MAX_M = 1.0
    GOAL_SEARCH_CENTER_MAX_XY_DISTANCE_M = 14.5
    GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_M = 3.5
    GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_CLUTTER_M = 8.0
    GOAL_CANDIDATE_MATCH_DISTANCE_M = 2.5
    GOAL_CANDIDATE_IMPROVEMENT_MARGIN_M = 0.75
    GOAL_SEARCH_SCORE_Z_WEIGHT_OPEN = 1.5
    GOAL_SEARCH_SCORE_Z_WEIGHT_CLUTTER = 0.35
    GOAL_CLOSE_TRACK_LOCK_DISTANCE_M = 2.0
    GOAL_CLOSE_TRACK_COLLAPSE_DISTANCE_M = 0.35
    GOAL_CLOSE_TRACK_MIN_STORED_DISTANCE_M = 0.75
    GOAL_TRACK_PREDICT_THRESHOLD_M = 0.08
    GOAL_TRACK_VELOCITY_ALPHA = 0.25
    GOAL_TRACK_MAX_SPEED_M_S = 1.8
    GOAL_TRACK_PRIORITY_WEIGHT_OPEN = 0.9
    GOAL_TRACK_PRIORITY_MAX_M = 6.0
    # State machine
    STATE1_TURN_YAW_STEP_NORM = 0.12
    STATE1_TURN_TARGET_OPEN_RAD = 0.8
    STATE1_TURN_TARGET_CLUTTER_RAD = 1.5
    STATE2_YAW_STEP_RAD = 0.08
    STATE3_HOVER_HEIGHT_M = 1.0
    STATE3_DESCENT_HORIZONTAL_DISTANCE_M = 1.0
    STATE3_FINAL_SPEED_M_S = 0.35
    STATE3_APPROACH_SPEED_M_S = 1.0
    STATE3_AT_TARGET_TOLERANCE_M = 0.08
    STATE3_AT_TARGET_SPEED_THRESHOLD_M_S = 0.1
    STATE3_FRONT_OBSTACLE_MIN_DEPTH_M = 2.0
    STATE3_TOUCHDOWN_BIAS_M = 0.25
    STATE3_TOUCHDOWN_SEARCH_RADIUS_M = 0.6
    STATE3_TOUCHDOWN_FINAL_DISTANCE_M = 0.06
    STATE3_TOUCHDOWN_FINAL_BIAS_M = 0.14
    STATE3_TILT_RECOVERY_RAD = 0.55
    STATE3_LOST_GOAL_NEAR_DISTANCE_M = 2.0
    STATE3_LOST_GOAL_NEAR_SPEED_M_S = 0.35
    STATE3_LOST_GOAL_FINAL_SPEED_M_S = 0.18
    STATE3_OPEN_STATIC_CONTACT_HORIZONTAL_M = 0.45
    STATE3_OPEN_MOVING_CONTACT_HORIZONTAL_M = 0.6
    STATE3_OPEN_HOVER_MARGIN_STATIC_M = 0.22
    STATE3_OPEN_HOVER_MARGIN_MOVING_M = 0.32
    STATE3_OPEN_DESCENT_STEP_STATIC_M = 0.18
    STATE3_OPEN_DESCENT_STEP_MOVING_M = 0.1
    STATE3_OPEN_APPROACH_SPEED_STATIC_M_S = 0.3
    STATE3_OPEN_APPROACH_SPEED_MOVING_M_S = 0.48
    STATE3_OPEN_CONTACT_SPEED_STATIC_M_S = 0.18
    STATE3_OPEN_CONTACT_SPEED_MOVING_M_S = 0.22
    OPEN_LIKE_DEPTH_MEDIAN_M = 19.0
    OPEN_LIKE_MAX_START_Z_M = 15.0
    OPEN_LIKE_CENTER_MEDIAN_M = 19.5
    ELEVATED_SEARCH_DEPTH_MEDIAN_THRESHOLD_M = 19.5
    ELEVATED_SEARCH_START_Z_THRESHOLD_M = 15.0
    ELEVATED_SEARCH_HEIGHT_MARGIN_M = 2.0

    def __init__(self):
        """Allocate mutable episode state. The benchmark calls :meth:`reset` before each run."""
        self.state = 0
        self.target = []
        self.search_area_center = None
        self.initial_position = None
        self.detected_goal_position = None
        self.detected_goal_direction = None
        self.state1_turning_270 = False
        self.state1_turn_270_prev_yaw = None
        self.state1_turn_270_swept_rad = 0.0
        self.state1_turn_direction = None
        self.state1_seeking_clear_direction = False
        self.state1_chosen_clear_direction = None
        self.state1_has_detour_waypoint = False
        self.state1_danger_steps_remaining = 0
        self.state1_search_point_index = 0
        self.state1_use_elevated_search = False
        self.state1_search_cruise_z = None
        self.scene_is_open_like = None
        self.state3_no_goal_steps = 0
        self.STATE3_NO_GOAL_LOOK_STEPS = 50
        self.act_step = 0
        self.MIN_STEPS_BEFORE_STATE3 = 0
        self.goal_detection_count = 0
        self.MIN_GOAL_DETECTIONS_BEFORE_STATE3 = 10
        self.MIN_GOAL_DETECTIONS_BEFORE_STATE3_CLUTTER = 3
        self.detected_goal_search_score = None
        self.detected_goal_observation_count = 0
        self.detected_goal_priority = None
        self.detected_goal_motion_ema = None
        self.detected_goal_velocity = None

    # ---------- Observation / state (inlined state_utils) ----------
    def _read_position_xyz(self, observation):
        """World position [x,y,z] in metres from observation state[0:3]."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            return np.asarray(state[0:3], dtype=np.float32)
        if hasattr(observation, "shape") and len(observation.shape) == 1 and observation.shape[0] >= 3:
            return np.asarray(observation[0:3], dtype=np.float32)
        return np.zeros(3, dtype=np.float32)

    def _read_velocity_xyz(self, observation):
        """Linear velocity [vx,vy,vz] (m/s) from ``state[6:9]`` when present."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            if len(state) >= 9:
                return np.asarray(state[6:9], dtype=np.float32)
        return np.zeros(3, dtype=np.float32)

    def _read_roll_pitch_rad(self, observation):
        """Roll and pitch (rad) from observation state[3] and state[4]."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            if len(state) >= 5:
                return float(state[3]), float(state[4])
        return 0.0, 0.0

    def _read_yaw_rad(self, observation):
        """Yaw (rad) from ``state[5]`` or None if missing."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            if len(state) >= 6:
                return float(state[5])
        return None

    def _read_angular_velocity(self, observation):
        """Body angular velocity [p,q,r] from observation state[9:12]."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            if len(state) >= 12:
                return np.asarray(state[9:12], dtype=np.float32)
        return np.zeros(3, dtype=np.float32)

    def _read_search_area_offset(self, observation):
        """Last three observation state values: offset to search-area anchor (world)."""
        if isinstance(observation, dict) and "state" in observation:
            state = observation["state"]
            if len(state) >= 3:
                return np.asarray(state[-3:], dtype=np.float32)
        return np.zeros(3, dtype=np.float32)

    # ---------- Depth / camera (inlined depth_utils) ----------
    def _project_world_direction_to_pixel(self, observation, direction_world, camera_fov_rad=None):
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        H, W = depth.shape
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        dir_w = np.asarray(direction_world, dtype=np.float32).reshape(3)
        dn = np.linalg.norm(dir_w)
        if dn < 1e-9:
            return None
        dir_w = dir_w / dn
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx
        ray_body = (R.T @ dir_w).astype(np.float32)
        if ray_body[0] <= 1e-6:
            return None
        half_fov = camera_fov_rad / 2.0
        horz = float(np.arctan2(-ray_body[1], ray_body[0]))
        vert = float(np.arctan2(-ray_body[2], ray_body[0]))
        c = (W - 1) / 2.0 + (W / 2.0) * (horz / half_fov)
        r = (H - 1) / 2.0 + (H / 2.0) * (vert / half_fov)
        r = int(np.clip(r, 0, H - 1))
        c = int(np.clip(c, 0, W - 1))
        return (r, c)

    def _unproject_pixel_to_world_direction(self, observation, r, c, camera_fov_rad=None):
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        H, W = depth.shape
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        half_fov = camera_fov_rad / 2.0
        horz = (c - (W - 1) / 2.0) / (W / 2.0) * half_fov
        vert = (r - (H - 1) / 2.0) / (H / 2.0) * half_fov
        ray_body = np.array([1.0, -np.tan(horz), -np.tan(vert)], dtype=np.float32)
        n = np.linalg.norm(ray_body)
        if n < 1e-9:
            ray_body = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        else:
            ray_body = ray_body / n
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx
        direction_world = (R @ ray_body).astype(np.float32)
        dn = float(np.linalg.norm(direction_world))
        if dn < 1e-9:
            return None
        return (direction_world / dn).astype(np.float32)

    def _camera_forward_in_world(self, observation, camera_fov_rad=None):
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx
        direction_world = (R @ np.array([1.0, 0.0, 0.0], dtype=np.float32)).astype(np.float32)
        dn = float(np.linalg.norm(direction_world))
        if dn < 1e-9:
            return None
        return (direction_world / dn).astype(np.float32)

    def _depth_along_world_direction(self, observation, direction_world, camera_fov_rad=None):
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        pixel = self._project_world_direction_to_pixel(observation, direction_world, camera_fov_rad=camera_fov_rad)
        if pixel is None:
            return None
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        r, c = pixel
        r = int(np.clip(r, 0, depth.shape[0] - 1))
        c = int(np.clip(c, 0, depth.shape[1] - 1))
        raw = float(depth[r, c])
        depth_m = 0.5 + 19.5 * np.clip(raw, 0.0, 1.0)
        return depth_m

    def _is_forward_center_clear_depth(self, observation, min_clear_m, front_patch_radius_px=None):
        if front_patch_radius_px is None:
            front_patch_radius_px = self.FRONT_PATCH_RADIUS_PX
        if not isinstance(observation, dict) or "depth" not in observation:
            return False
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False
        H, W = depth.shape
        c0 = max(0, W // 2 - front_patch_radius_px)
        c1 = min(W, W // 2 + front_patch_radius_px + 1)
        min_raw = float(np.min(depth[H // 2, c0:c1]))
        return (0.5 + 19.5 * min_raw) >= min_clear_m

    def _depth_median_m(self, observation):
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        return float(np.median(0.5 + 19.5 * depth))

    def _front_patch_obstacle_too_close(
        self,
        observation,
        current_velocity,
        roll,
        pitch,
        yaw,
        front_obstacle_min_depth_m=None,
        front_patch_rows=None,
        front_patch_cols=None,
        camera_fov_rad=None,
    ):
        if front_obstacle_min_depth_m is None:
            front_obstacle_min_depth_m = self.FRONT_OBSTACLE_MIN_DEPTH_M
        if front_patch_rows is None:
            front_patch_rows = self.FRONT_PATCH_ROWS
        if front_patch_cols is None:
            front_patch_cols = self.FRONT_PATCH_COLS
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation:
            return False
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False
        H, W = depth.shape
        vel = np.asarray(current_velocity, dtype=np.float32).reshape(3)
        speed = float(np.linalg.norm(vel))
        if speed > 0.1:
            direction_world = vel / speed
        else:
            cy, sy = np.cos(yaw), np.sin(yaw)
            cp, sp = np.cos(pitch), np.sin(pitch)
            cr, sr = np.cos(roll), np.sin(roll)
            Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
            Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
            Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
            R = Rz @ Ry @ Rx
            direction_world = (R @ np.array([1.0, 0.0, 0.0], dtype=np.float32))
            dn = np.linalg.norm(direction_world)
            if dn < 1e-9:
                return False
            direction_world = direction_world / dn
        pixel = self._project_world_direction_to_pixel(observation, direction_world, camera_fov_rad=camera_fov_rad)
        if pixel is None:
            return False
        pr, pc = pixel
        n, m = front_patch_rows, front_patch_cols
        r0 = max(0, pr - (n - 1) // 2)
        r1 = min(H, pr + (n - 1) // 2 + 1)
        c0 = max(0, pc - (m - 1) // 2)
        c1 = min(W, pc + (m - 1) // 2 + 1)
        min_raw = float(np.min(depth[r0:r1, c0:c1]))
        return (0.5 + 19.5 * min_raw) < front_obstacle_min_depth_m

    def _min_depth_in_velocity_front_patch(
        self,
        observation,
        current_velocity,
        roll,
        pitch,
        yaw,
        front_patch_rows=None,
        front_patch_cols=None,
        camera_fov_rad=None,
    ):
        if front_patch_rows is None:
            front_patch_rows = self.FRONT_PATCH_ROWS
        if front_patch_cols is None:
            front_patch_cols = self.FRONT_PATCH_COLS
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        H, W = depth.shape
        vel = np.asarray(current_velocity, dtype=np.float32).reshape(3)
        speed = float(np.linalg.norm(vel))
        if speed > 0.1:
            direction_world = vel / speed
        else:
            cy, sy = np.cos(yaw), np.sin(yaw)
            cp, sp = np.cos(pitch), np.sin(pitch)
            cr, sr = np.cos(roll), np.sin(roll)
            Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
            Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
            Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
            R = Rz @ Ry @ Rx
            direction_world = (R @ np.array([1.0, 0.0, 0.0], dtype=np.float32))
            dn = np.linalg.norm(direction_world)
            if dn < 1e-9:
                return None
            direction_world = direction_world / dn
        pixel = self._project_world_direction_to_pixel(observation, direction_world, camera_fov_rad=camera_fov_rad)
        if pixel is None:
            return None
        pr, pc = pixel
        n, m = front_patch_rows, front_patch_cols
        r0 = max(0, pr - (n - 1) // 2)
        r1 = min(H, pr + (n - 1) // 2 + 1)
        c0 = max(0, pc - (m - 1) // 2)
        c1 = min(W, pc + (m - 1) // 2 + 1)
        return float(0.5 + 19.5 * np.min(depth[r0:r1, c0:c1]))

    def _lateral_close_obstacle_corridor_clear(self, observation, danger_distance_m=None):
        """True only when front is clear (no close obstacle) AND left or right has close obstacle."""
        if danger_distance_m is None:
            danger_distance_m = self.DANGER_DISTANCE_M
        if not isinstance(observation, dict) or "depth" not in observation:
            return False
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False
        H, W = depth.shape
        c1, c2 = W // 3, 2 * W // 3
        raw_to_m = lambda raw: 0.5 + 19.5 * float(raw)
        front_min = raw_to_m(np.min(depth[:, c1:c2])) if c2 > c1 else raw_to_m(np.min(depth))
        left_min = raw_to_m(np.min(depth[:, :c1])) if c1 > 0 else float("inf")
        right_min = raw_to_m(np.min(depth[:, c2:])) if c2 < W else float("inf")
        return front_min >= danger_distance_m and (left_min < danger_distance_m or right_min < danger_distance_m)

    def _movement_direction_pixel(self, observation, current_velocity, roll, pitch, yaw, camera_fov_rad=None):
        """Return (r, c) of the pixel in the movement direction (world frame), or None."""
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        vel = np.asarray(current_velocity, dtype=np.float32).reshape(3)
        speed = float(np.linalg.norm(vel))
        if speed > 0.1:
            direction_world = vel / speed
        else:
            cy, sy = np.cos(yaw), np.sin(yaw)
            cp, sp = np.cos(pitch), np.sin(pitch)
            cr, sr = np.cos(roll), np.sin(roll)
            Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
            Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
            Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
            R = Rz @ Ry @ Rx
            direction_world = (R @ np.array([1.0, 0.0, 0.0], dtype=np.float32))
            dn = np.linalg.norm(direction_world)
            if dn < 1e-9:
                return None
            direction_world = direction_world / dn
        return self._project_world_direction_to_pixel(observation, direction_world, camera_fov_rad=camera_fov_rad)

    def _detour_waypoint_from_obstacle_cc(
        self,
        observation,
        current_pos,
        final_target,
        obstacle_depth_m,
        current_velocity,
        roll,
        pitch,
        yaw,
        camera_fov_rad=None,
        obstacle_margin_m=0.5,
        height_tolerance_m=1.0,
        min_clear_distance_px=None,
    ):
        """Find obstacle CC containing front pixel; forbidden = CC+10px and depth<obstacle+10px; pick closest to final_target."""
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if min_clear_distance_px is None:
            min_clear_distance_px = self.DETOUR_MIN_CLEAR_DISTANCE_PX
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        H, W = depth.shape
        depth_meters = 0.5 + 19.5 * np.clip(depth, 0.0, 1.0)
        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        final = np.asarray(final_target, dtype=np.float32).reshape(3)
        target_z = float(final[2])
        z_lo = target_z - height_tolerance_m
        z_hi = target_z + height_tolerance_m

        threshold = float(obstacle_depth_m) + obstacle_margin_m
        obstacle_mask = (depth_meters < threshold).astype(np.uint8)

        front_pixel = self._movement_direction_pixel(observation, current_velocity, roll, pitch, yaw, camera_fov_rad=camera_fov_rad)
        if front_pixel is None:
            return None
        pr, pc = front_pixel
        pr, pc = int(np.clip(pr, 0, H - 1)), int(np.clip(pc, 0, W - 1))

        component_mask = np.zeros((H, W), dtype=bool)
        queue = [(pr, pc)]
        while queue:
            r, c = queue.pop()
            if r < 0 or r >= H or c < 0 or c >= W:
                continue
            if component_mask[r, c]:
                continue
            if not obstacle_mask[r, c]:
                continue
            component_mask[r, c] = True
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                queue.append((r + dr, c + dc))

        k = min_clear_distance_px
        near_obstacle_mask = (depth_meters < float(obstacle_depth_m))
        bad_mask = component_mask | near_obstacle_mask
        forbidden = np.zeros((H, W), dtype=bool)
        q = deque()
        bad_r, bad_c = np.nonzero(bad_mask)
        forbidden[bad_r, bad_c] = True
        q = deque(zip(bad_r.tolist(), bad_c.tolist(), [0]*len(bad_r)))
        neighbors_8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
        while q:
            r, c, d = q.popleft()
            if d + 1 >= k:
                continue
            for dr, dc in neighbors_8:
                nr, nc = r + dr, c + dc
                if 0 <= nr < H and 0 <= nc < W and not forbidden[nr, nc]:
                    forbidden[nr, nc] = True
                    q.append((nr, nc, d + 1))

        candidate_mask = ~forbidden

        roll_v, pitch_v = self._read_roll_pitch_rad(observation)
        yaw_v = self._read_yaw_rad(observation)
        if yaw_v is None:
            yaw_v = 0.0
        half_fov = camera_fov_rad / 2.0
        cr_v, sr_v = np.cos(roll_v), np.sin(roll_v)
        cp_v, sp_v = np.cos(pitch_v), np.sin(pitch_v)
        cy_v, sy_v = np.cos(yaw_v), np.sin(yaw_v)
        Rx = np.array([[1, 0, 0], [0, cr_v, -sr_v], [0, sr_v, cr_v]], dtype=np.float32)
        Ry = np.array([[cp_v, 0, sp_v], [0, 1, 0], [-sp_v, 0, cp_v]], dtype=np.float32)
        Rz = np.array([[cy_v, -sy_v, 0], [sy_v, cy_v, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx

        cand_r, cand_c = np.nonzero(candidate_mask)
        if len(cand_r) == 0:
            return None
        horz = (cand_c.astype(np.float32) - (W - 1) / 2.0) / (W / 2.0) * half_fov
        vert = (cand_r.astype(np.float32) - (H - 1) / 2.0) / (H / 2.0) * half_fov
        rx = np.ones(len(cand_r), dtype=np.float32)
        ry = -np.tan(horz); rz_arr = -np.tan(vert)
        rn = np.sqrt(rx**2 + ry**2 + rz_arr**2)
        rn = np.maximum(rn, 1e-9)
        rx /= rn; ry /= rn; rz_arr /= rn
        dw_x = R[0, 0]*rx + R[0, 1]*ry + R[0, 2]*rz_arr
        dw_y = R[1, 0]*rx + R[1, 1]*ry + R[1, 2]*rz_arr
        dw_z = R[2, 0]*rx + R[2, 1]*ry + R[2, 2]*rz_arr
        dn_arr = np.sqrt(dw_x**2 + dw_y**2 + dw_z**2)
        dn_arr = np.maximum(dn_arr, 1e-9)
        dw_x /= dn_arr; dw_y /= dn_arr; dw_z /= dn_arr

        dm = depth_meters[cand_r, cand_c]
        pos_x = cur[0] + dm * dw_x
        pos_y = cur[1] + dm * dw_y
        pos_z = cur[2] + dm * dw_z

        in_band = (pos_z >= z_lo) & (pos_z <= z_hi)
        small_dz = np.abs(dw_z) < 1e-9
        cur_in_band = (z_lo <= cur[2] <= z_hi)
        case2 = small_dz & (~in_band) & cur_in_band

        t_lo_arr = np.where(np.abs(dw_z) > 1e-9, (z_lo - cur[2]) / dw_z, 0.0)
        t_hi_arr = np.where(np.abs(dw_z) > 1e-9, (z_hi - cur[2]) / dw_z, 0.0)
        t_min_arr = np.minimum(t_lo_arr, t_hi_arr)
        t_max_arr = np.maximum(t_lo_arr, t_hi_arr)
        tv_lo = np.maximum(0.0, t_min_arr)
        tv_hi = np.minimum(dm, t_max_arr)
        case3 = (~in_band) & (~small_dz) & (tv_lo <= tv_hi)

        valid = in_band | case2 | case3
        if not np.any(valid):
            return None

        wp_x = np.where(in_band, pos_x, np.where(case3, cur[0] + tv_hi * dw_x, pos_x))
        wp_y = np.where(in_band, pos_y, np.where(case3, cur[1] + tv_hi * dw_y, pos_y))
        wp_z = np.where(in_band, pos_z, np.where(case3, cur[2] + tv_hi * dw_z, pos_z))

        vi = np.nonzero(valid)[0]
        wp_x = wp_x[vi]; wp_y = wp_y[vi]; wp_z = wp_z[vi]
        dist_to_final = np.sqrt((wp_x - final[0])**2 + (wp_y - final[1])**2 + (wp_z - final[2])**2)
        best_idx = int(np.argmin(dist_to_final))
        return np.array([wp_x[best_idx], wp_y[best_idx], wp_z[best_idx]], dtype=np.float32)

    def _clearest_horizontal_toward_search_center(
        self,
        observation,
        direction_to_center,
        top_k=5,
        patch_size=5,
        camera_fov_rad=None,
        max_vertical_component=None,
        min_clear_depth_m=None,
        clear_margin_m=None,
    ):
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if max_vertical_component is None:
            max_vertical_component = self.MAX_VERTICAL_COMPONENT_HORIZONTAL
        if clear_margin_m is None:
            clear_margin_m = self.CLEAR_DIRECTION_MIN_MARGIN_M
        if not isinstance(observation, dict) or "depth" not in observation:
            return None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return None
        H, W = depth.shape
        depth_meters = 0.5 + 19.5 * depth
        to_center = np.asarray(direction_to_center, dtype=np.float32).reshape(3)
        dn = float(np.linalg.norm(to_center))
        if dn < 1e-9:
            to_center = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        else:
            to_center = to_center / dn
        half = patch_size // 2
        roll_v, pitch_v = self._read_roll_pitch_rad(observation)
        yaw_v = self._read_yaw_rad(observation)
        if yaw_v is None:
            yaw_v = 0.0
        half_fov = camera_fov_rad / 2.0
        cr, sr = np.cos(roll_v), np.sin(roll_v)
        cp, sp = np.cos(pitch_v), np.sin(pitch_v)
        cy, sy = np.cos(yaw_v), np.sin(yaw_v)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx
        rows = np.arange(H, dtype=np.float32)
        cols = np.arange(W, dtype=np.float32)
        cc, rr = np.meshgrid(cols, rows)
        horz = (cc - (W - 1) / 2.0) / (W / 2.0) * half_fov
        vert = (rr - (H - 1) / 2.0) / (H / 2.0) * half_fov
        ray_x = np.ones((H, W), dtype=np.float32)
        ray_y = -np.tan(horz)
        ray_z = -np.tan(vert)
        ray_norm = np.sqrt(ray_x**2 + ray_y**2 + ray_z**2)
        ray_norm = np.maximum(ray_norm, 1e-9)
        ray_x /= ray_norm; ray_y /= ray_norm; ray_z /= ray_norm
        dw_x = R[0, 0]*ray_x + R[0, 1]*ray_y + R[0, 2]*ray_z
        dw_y = R[1, 0]*ray_x + R[1, 1]*ray_y + R[1, 2]*ray_z
        dw_z = R[2, 0]*ray_x + R[2, 1]*ray_y + R[2, 2]*ray_z
        dn = np.sqrt(dw_x**2 + dw_y**2 + dw_z**2)
        dn = np.maximum(dn, 1e-9)
        dw_x /= dn; dw_y /= dn; dw_z /= dn
        vert_ok = np.abs(dw_z) <= max_vertical_component
        if min_clear_depth_m is not None:
            min_depth_map = minimum_filter(depth_meters, size=patch_size, mode='constant', cval=0.0)
            depth_ok = min_depth_map >= min_clear_depth_m
        else:
            depth_ok = np.ones((H, W), dtype=bool)
        valid = vert_ok & depth_ok
        if not np.any(valid):
            return None
        to_center_xy = np.array([to_center[0], to_center[1]], dtype=np.float32)
        to_center_xy_norm = float(np.linalg.norm(to_center_xy))
        if to_center_xy_norm < 1e-9:
            to_center_xy = np.array([1.0, 0.0], dtype=np.float32)
        else:
            to_center_xy = to_center_xy / to_center_xy_norm
        dir_xy_norm = np.sqrt(dw_x**2 + dw_y**2)
        dir_xy_norm = np.maximum(dir_xy_norm, 1e-9)
        cos_map = (dw_x * to_center_xy[0] + dw_y * to_center_xy[1]) / dir_xy_norm
        cos_map = np.clip(cos_map, -1.0, 1.0)
        angle_map = np.arccos(cos_map)
        angle_map[~valid] = 1e9
        best_idx = np.argmin(angle_map)
        br, bc = divmod(int(best_idx), W)
        if angle_map[br, bc] > 1e8:
            return None
        out = np.array([dw_x[br, bc], dw_y[br, bc], 0.0], dtype=np.float32)
        n = float(np.linalg.norm(out))
        if n < 1e-9:
            return None
        return (out / n).astype(np.float32)

    # ---------- Movement (inlined; logic aligned with movement.py) ----------
    def _tilt_accel_scale(self, roll, pitch):
        """Scale in (0, 1]: 1 when level, lower when roll/pitch high."""
        tilt = max(abs(roll), abs(pitch))
        if tilt >= self.MAX_SAFE_ROLL_PITCH_RAD:
            return self.ACCEL_SCALE_AT_HIGH_TILT
        return 1.0 - (1.0 - self.ACCEL_SCALE_AT_HIGH_TILT) * (tilt / self.MAX_SAFE_ROLL_PITCH_RAD)

    def _angular_rate_accel_scale(self, roll_rate, pitch_rate):
        """Scale in (0, 1]: 1 when stable, lower when angular velocity high."""
        ang_vel_magnitude = max(abs(roll_rate), abs(pitch_rate))
        if ang_vel_magnitude >= self.MAX_SAFE_ANGULAR_VEL_RAD_S:
            return self.ACCEL_SCALE_AT_HIGH_ANG_VEL
        return 1.0 - (1.0 - self.ACCEL_SCALE_AT_HIGH_ANG_VEL) * (
            ang_vel_magnitude / self.MAX_SAFE_ANGULAR_VEL_RAD_S
        )

    def _approach_angle_speed_scale(self, current_velocity, desired_direction):
        """Scale in (0, 1] for speed based on angle between current velocity and desired direction."""
        vel = np.asarray(current_velocity, dtype=np.float32).reshape(3)
        dir_vec = np.asarray(desired_direction, dtype=np.float32).reshape(3)
        nv = float(np.linalg.norm(vel))
        if nv < 1e-6:
            return 1.0
        cos_angle = float(np.dot(vel, dir_vec)) / (nv + 1e-9)
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        angle = float(np.arccos(cos_angle))
        scale = 1.0 - (1.0 - self.SPEED_SCALE_AT_LARGE_ANGLE) * min(
            1.0, angle / self.MAX_APPROACH_ANGLE_RAD
        )
        return float(np.clip(scale, self.SPEED_SCALE_AT_LARGE_ANGLE, 1.0))

    def _velocity_command_toward_point(
        self,
        current_pos,
        target_point,
        current_velocity,
        roll=None,
        pitch=None,
        roll_rate=None,
        pitch_rate=None,
        max_speed_m_s=None,
        deceleration_start_distance=None,
        at_target_tolerance=None,
        at_target_speed_threshold=None,
        yaw_face_direction_min_distance_m=None,
        max_velocity_change_norm_m_s=None,
        **kwargs,
    ):
        """Compute action [vx, vy, vz, speed, yaw] to move toward target_point (logic from movement.py)."""
        if max_speed_m_s is None:
            max_speed_m_s = self.MAX_SPEED_M_S
        if deceleration_start_distance is None:
            deceleration_start_distance = self.DECELERATION_START_DISTANCE
        if at_target_tolerance is None:
            at_target_tolerance = self.AT_TARGET_TOLERANCE
        if at_target_speed_threshold is None:
            at_target_speed_threshold = self.AT_TARGET_SPEED_THRESHOLD
        if yaw_face_direction_min_distance_m is None:
            yaw_face_direction_min_distance_m = self.YAW_FACE_DIRECTION_MIN_DISTANCE_M
        if max_velocity_change_norm_m_s is None:
            max_velocity_change_norm_m_s = self.MAX_VELOCITY_CHANGE_NORM_M_S
        current = np.asarray(current_pos, dtype=np.float32).reshape(3)
        target = np.asarray(target_point, dtype=np.float32).reshape(3)
        vel = np.asarray(current_velocity, dtype=np.float32).reshape(3)
        diff = target - current
        distance = float(np.linalg.norm(diff))
        if distance < at_target_tolerance and float(np.linalg.norm(vel)) < at_target_speed_threshold:
            return np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        if distance < 1e-6:
            direction = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        else:
            direction = diff / distance
        if distance < deceleration_start_distance:
            decel_range = deceleration_start_distance
            if decel_range > 0:
                speed_factor = distance / decel_range
                desired_speed_cap = max_speed_m_s * max(0.0, min(1.0, speed_factor))
            else:
                desired_speed_cap = 0.0
        else:
            desired_speed_cap = max_speed_m_s
        scale = 1.0
        if roll is not None and pitch is not None:
            scale = min(scale, self._tilt_accel_scale(roll, pitch))
        if roll_rate is not None and pitch_rate is not None:
            scale = min(scale, self._angular_rate_accel_scale(roll_rate, pitch_rate))
        desired_speed_cap *= scale
        if distance >= 1e-6:
            angle_scale = self._approach_angle_speed_scale(vel, direction)
            desired_speed_cap *= angle_scale
        goal_velocity = direction * desired_speed_cap
        goal_norm = float(np.linalg.norm(goal_velocity))
        if goal_norm > 1e-6:
            goal_velocity_unit = goal_velocity / goal_norm
        else:
            goal_velocity_unit = direction
        current_speed = float(np.linalg.norm(vel))
        if current_speed < 1e-6:
            current_speed_in_goal_direction = 0.0
        else:
            cos_angle = float(np.dot(vel, goal_velocity_unit)) / (current_speed + 1e-9)
            cos_angle = np.clip(cos_angle, -1.0, 1.0)
            current_speed_in_goal_direction = current_speed * cos_angle
        desired_speed_from_max_change = current_speed_in_goal_direction + max_velocity_change_norm_m_s
        desired_speed = min(
            desired_speed_cap,
            max(0.0, desired_speed_from_max_change),
            max_speed_m_s,
        )
        velocity_direction_vector = direction
        velocity = velocity_direction_vector * desired_speed
        speed = float(np.linalg.norm(velocity))
        if speed > max_speed_m_s and speed > 1e-6:
            velocity = velocity * (max_speed_m_s / speed)
            speed = max_speed_m_s
        desired_yaw_norm = None
        horiz_dist = float(np.sqrt(diff[0] * diff[0] + diff[1] * diff[1]))
        if horiz_dist >= yaw_face_direction_min_distance_m:
            dir_xy_norm = float(np.sqrt(direction[0] ** 2 + direction[1] ** 2))
            if dir_xy_norm > 1e-6:
                desired_yaw = float(np.arctan2(direction[1], direction[0]))
                desired_yaw_norm = float(np.clip(desired_yaw / np.pi, -1.0, 1.0))
        action = np.zeros(5, dtype=np.float32)
        action[0] = velocity[0]
        action[1] = velocity[1]
        action[2] = velocity[2]
        action[3] = speed
        action[4] = desired_yaw_norm if desired_yaw_norm is not None else 0.0
        return action

    # ---------- Search area (inlined search_area) ----------
    def _world_search_center_from_offset(self, current_pos, search_area_vector):
        current = np.asarray(current_pos, dtype=np.float32).reshape(3)
        vector = np.asarray(search_area_vector, dtype=np.float32).reshape(3)
        return current + vector

    def _waypoints_for_height_match(self, current_pos, center, horizontal_m=None, rise_height_m=None):
        if horizontal_m is None:
            horizontal_m = self.HORIZONTAL_M
        if rise_height_m is None:
            rise_height_m = self.RISE_HEIGHT_M
        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        cen = np.asarray(center, dtype=np.float32).reshape(3)
        waypoints = []
        if self.state1_use_elevated_search:
            cruise_z = max(float(cur[2]), float(cen[2]) + self.ELEVATED_SEARCH_HEIGHT_MARGIN_M)
            if cruise_z > cur[2] + 0.15:
                waypoints.append(np.array([cur[0], cur[1], cruise_z], dtype=np.float32))
            else:
                waypoints.append(cur.copy())
            return waypoints
        if cen[2] - 1 > cur[2]:
            waypoints.append(np.array([cur[0], cur[1], max(0.6, cen[2] - 1)], dtype=np.float32))
        else:
            dx = cen[0] - cur[0]
            dy = cen[1] - cur[1]
            hor_norm = np.sqrt(dx * dx + dy * dy)
            if hor_norm > 1e-6:
                dx, dy = dx / hor_norm, dy / hor_norm
            else:
                dx, dy = 1.0, 0.0
            mid_x = cur[0] + dx * horizontal_m
            mid_y = cur[1] + dy * horizontal_m
            mid_z = cur[2] + rise_height_m
            waypoints.append(np.array([mid_x, mid_y, mid_z], dtype=np.float32))
            waypoints.append(np.array([mid_x, mid_y, max(0.6, cen[2] - 1)], dtype=np.float32))
        return waypoints

    def _random_point_in_search_ellipsoid(
        self, search_area_center, radius_x=None, radius_y=None, radius_z=None
    ):
        if radius_x is None:
            radius_x = self.SEARCH_AREA_RADIUS_X_M
        if radius_y is None:
            radius_y = self.SEARCH_AREA_RADIUS_Y_M
        if radius_z is None:
            radius_z = self.SEARCH_AREA_RADIUS_Z_M
        center = np.asarray(search_area_center, dtype=np.float32).reshape(3)
        offset_x = np.random.uniform(-radius_x, radius_x)
        offset_y = np.random.uniform(-radius_y, radius_y)
        offset_z = np.random.uniform(-radius_z, radius_z)
        point = center + np.array([offset_x, offset_y, offset_z], dtype=np.float32)
        point[2] = np.clip(point[2], 1.0, 10.0)
        return point

    # ---------- Goal detection (inlined goal_detection) ----------
    def _near_depth_bearing(
        self,
        observation,
        max_depth_m=None,
        depth_range_near_m=None,
        depth_range_far_m=None,
        camera_fov_rad=None,
    ):
        if max_depth_m is None:
            max_depth_m = self.NEAR_GOAL_DEPTH_MAX_M
        if depth_range_near_m is None:
            depth_range_near_m = self.DEPTH_RANGE_NEAR_M
        if depth_range_far_m is None:
            depth_range_far_m = self.DEPTH_RANGE_FAR_M
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if not isinstance(observation, dict) or "depth" not in observation or "state" not in observation:
            return (None,)
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return (None,)
        H, W = depth.shape
        depth_meters = 0.5 + 19.5 * depth
        current_pos = self._read_position_xyz(observation)
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        half_fov = camera_fov_rad / 2.0
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx
        near_mask = depth_meters < max_depth_m
        near_r, near_c = np.nonzero(near_mask)
        if len(near_r) == 0:
            return (None,)
        cur_f = np.asarray(current_pos, dtype=np.float32).reshape(3)
        dm = np.clip(depth_meters[near_r, near_c], depth_range_near_m, depth_range_far_m)
        h = (near_c.astype(np.float32) - (W - 1) / 2.0) / (W / 2.0) * half_fov
        v = (near_r.astype(np.float32) - (H - 1) / 2.0) / (H / 2.0) * half_fov
        rx = np.ones(len(near_r), dtype=np.float32)
        ry = -np.tan(h); rz = -np.tan(v)
        rn = np.sqrt(rx**2 + ry**2 + rz**2)
        rn = np.maximum(rn, 1e-9)
        rx /= rn; ry /= rn; rz /= rn
        dx = R[0, 0]*rx + R[0, 1]*ry + R[0, 2]*rz
        dy = R[1, 0]*rx + R[1, 1]*ry + R[1, 2]*rz
        dz = R[2, 0]*rx + R[2, 1]*ry + R[2, 2]*rz
        dn_arr = np.sqrt(dx**2 + dy**2 + dz**2)
        dn_arr = np.maximum(dn_arr, 1e-9)
        dx /= dn_arr; dy /= dn_arr; dz /= dn_arr
        avg_x = float(np.mean(cur_f[0] + dm * dx))
        avg_y = float(np.mean(cur_f[1] + dm * dy))
        avg_z = float(np.mean(cur_f[2] + dm * dz))
        avg_position = np.array([avg_x, avg_y, avg_z], dtype=np.float32)
        to_avg = avg_position - cur_f
        dn = float(np.linalg.norm(to_avg))
        if dn < 1e-6:
            return (None,)
        direction_world = (to_avg / dn).astype(np.float32)
        return (direction_world,)

    def _goal_candidate_distance_score(self, position_world):
        if self.search_area_center is None:
            return 0.0
        center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
        pos = np.asarray(position_world, dtype=np.float32).reshape(3)
        xy_dist = float(np.linalg.norm(pos[:2] - center[:2]))
        z_dist = abs(float(pos[2] - center[2]))
        z_weight = self.GOAL_SEARCH_SCORE_Z_WEIGHT_OPEN if bool(self.scene_is_open_like) else self.GOAL_SEARCH_SCORE_Z_WEIGHT_CLUTTER
        return xy_dist + z_weight * z_dist

    def _goal_in_search_bounds(self, position_world):
        if self.search_area_center is None:
            return True
        center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
        pos = np.asarray(position_world, dtype=np.float32).reshape(3)
        xy_dist = float(np.linalg.norm(pos[:2] - center[:2]))
        z_dist = abs(float(pos[2] - center[2]))
        max_z_dist = self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_M if bool(self.scene_is_open_like) else self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_CLUTTER_M
        return (
            xy_dist <= self.GOAL_SEARCH_CENTER_MAX_XY_DISTANCE_M
            and z_dist <= max_z_dist
        )

    def _fuse_goal_observation(self, direction_world, position_world, current_pos=None):
        candidate = np.asarray(position_world, dtype=np.float32).reshape(3)
        candidate_score = self._goal_candidate_distance_score(candidate)
        candidate_dir = np.asarray(direction_world, dtype=np.float32).reshape(3)
        cand_dn = float(np.linalg.norm(candidate_dir))
        if cand_dn > 1e-6:
            candidate_dir = candidate_dir / cand_dn

        if self.detected_goal_position is None or self.detected_goal_observation_count <= 0:
            self.detected_goal_position = candidate.copy()
            self.detected_goal_direction = candidate_dir.copy()
            self.detected_goal_search_score = candidate_score
            self.detected_goal_observation_count = 1
            return True

        stored = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3)
        current = None
        if current_pos is not None:
            current = np.asarray(current_pos, dtype=np.float32).reshape(3)
        stored_score = (
            float(self.detected_goal_search_score)
            if self.detected_goal_search_score is not None
            else self._goal_candidate_distance_score(stored)
        )

        if float(np.linalg.norm(candidate - stored)) <= self.GOAL_CANDIDATE_MATCH_DISTANCE_M:
            self.detected_goal_position = candidate.copy()
            self.detected_goal_direction = candidate_dir.copy()
            self.detected_goal_search_score = candidate_score
            self.detected_goal_observation_count = min(int(self.detected_goal_observation_count), 9) + 1
            return True

        if current is not None:
            stored_self_dist = float(np.linalg.norm(stored - current))
            candidate_self_dist = float(np.linalg.norm(candidate - current))
            if (
                stored_self_dist >= 3.0
                and candidate_self_dist <= 2.5
                and candidate_self_dist + 2.0 < stored_self_dist
            ):
                return False

        confidence_margin = self.GOAL_CANDIDATE_IMPROVEMENT_MARGIN_M + 0.25 * max(0, min(int(self.detected_goal_observation_count) - 1, 6))
        if candidate_score + confidence_margin < stored_score:
            self.detected_goal_position = candidate.copy()
            self.detected_goal_direction = candidate_dir.copy()
            self.detected_goal_search_score = candidate_score
            self.detected_goal_observation_count = 1
            return True

        return False

    def _assign_detected_goal(self, direction_world, position_world):
        self.detected_goal_position = np.asarray(position_world, dtype=np.float32).reshape(3).copy()
        self.detected_goal_direction = np.asarray(direction_world, dtype=np.float32).reshape(3).copy()
        self.detected_goal_search_score = self._goal_candidate_distance_score(self.detected_goal_position)
        self.detected_goal_observation_count = 1

    def _clear_goal_kinematics(self):
        self.detected_goal_motion_ema = None
        self.detected_goal_velocity = None

    def _update_goal_kinematics_ema(self, previous_position, candidate_position):
        prev = np.asarray(previous_position, dtype=np.float32).reshape(3)
        cand = np.asarray(candidate_position, dtype=np.float32).reshape(3)
        delta = cand - prev
        motion = float(np.linalg.norm(delta))
        if self.detected_goal_motion_ema is None:
            self.detected_goal_motion_ema = motion
        else:
            self.detected_goal_motion_ema = 0.8 * float(self.detected_goal_motion_ema) + 0.2 * motion

        dt = max(float(self.SIM_DT), 1e-6)
        raw_velocity = delta / dt
        raw_velocity[2] = 0.0
        raw_speed = float(np.linalg.norm(raw_velocity))
        if raw_speed > self.GOAL_TRACK_MAX_SPEED_M_S and raw_speed > 1e-6:
            raw_velocity *= self.GOAL_TRACK_MAX_SPEED_M_S / raw_speed
        if self.detected_goal_velocity is None:
            self.detected_goal_velocity = raw_velocity.astype(np.float32)
        else:
            prev_velocity = np.asarray(self.detected_goal_velocity, dtype=np.float32).reshape(3)
            alpha = self.GOAL_TRACK_VELOCITY_ALPHA
            self.detected_goal_velocity = ((1.0 - alpha) * prev_velocity + alpha * raw_velocity).astype(np.float32)
        return motion

    def _lead_compensated_goal(self, current_pos=None):
        if self.detected_goal_position is None:
            return None
        ref = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3).copy()
        if (
            current_pos is None
            or self.detected_goal_velocity is None
            or self.detected_goal_motion_ema is None
            or float(self.detected_goal_motion_ema) < self.GOAL_TRACK_PREDICT_THRESHOLD_M
        ):
            return ref
        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        horiz_dist = float(np.linalg.norm(ref[:2] - cur[:2]))
        lead_time = float(np.clip(0.18 + 0.1 * horiz_dist, 0.25, 0.8))
        ref[:2] += np.asarray(self.detected_goal_velocity, dtype=np.float32).reshape(3)[:2] * lead_time
        return ref

    def _state3_open_approach_command(
        self,
        current_pos,
        current_velocity,
        roll,
        pitch,
        roll_rate,
        pitch_rate,
        yaw,
    ):
        if self.detected_goal_position is None:
            return None

        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        target_goal = self._lead_compensated_goal(current_pos=cur)
        if target_goal is None:
            return None
        target_goal = np.asarray(target_goal, dtype=np.float32).reshape(3).copy()
        moving_like = (
            self.detected_goal_motion_ema is not None
            and float(self.detected_goal_motion_ema) >= self.GOAL_TRACK_PREDICT_THRESHOLD_M
        )
        horiz_dist = float(np.linalg.norm(target_goal[:2] - cur[:2]))

        if horiz_dist < 1.5 and max(abs(roll), abs(pitch)) > self.STATE3_TILT_RECOVERY_RAD:
            action = np.zeros(5, dtype=np.float32)
            action[4] = float(np.clip((yaw if yaw is not None else 0.0) / np.pi, -1.0, 1.0))
            return action

        contact_horiz = (
            self.STATE3_OPEN_MOVING_CONTACT_HORIZONTAL_M
            if moving_like
            else self.STATE3_OPEN_STATIC_CONTACT_HORIZONTAL_M
        )
        hover_margin = (
            self.STATE3_OPEN_HOVER_MARGIN_MOVING_M
            if moving_like
            else self.STATE3_OPEN_HOVER_MARGIN_STATIC_M
        )
        descent_step = (
            self.STATE3_OPEN_DESCENT_STEP_MOVING_M
            if moving_like
            else self.STATE3_OPEN_DESCENT_STEP_STATIC_M
        )
        approach_speed = (
            self.STATE3_OPEN_APPROACH_SPEED_MOVING_M_S
            if moving_like
            else self.STATE3_OPEN_APPROACH_SPEED_STATIC_M_S
        )
        contact_speed = (
            self.STATE3_OPEN_CONTACT_SPEED_MOVING_M_S
            if moving_like
            else self.STATE3_OPEN_CONTACT_SPEED_STATIC_M_S
        )

        if horiz_dist > contact_horiz:
            target = target_goal.copy()
            if moving_like:
                target[2] = max(cur[2], target_goal[2] + hover_margin)
            else:
                target[2] = min(cur[2], max(target_goal[2] + hover_margin, cur[2] - 0.08))
            return self._velocity_command_toward_point(
                current_pos,
                target,
                current_velocity,
                roll=roll,
                pitch=pitch,
                roll_rate=roll_rate,
                pitch_rate=pitch_rate,
                max_speed_m_s=approach_speed,
                deceleration_start_distance=max(0.6, 0.8 * horiz_dist),
                at_target_tolerance=0.06,
                at_target_speed_threshold=0.05,
                yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
            )

        target = target_goal.copy()
        target[2] = min(target_goal[2] - 0.08, cur[2] - descent_step)
        return self._velocity_command_toward_point(
            current_pos,
            target,
            current_velocity,
            roll=roll,
            pitch=pitch,
            roll_rate=roll_rate,
            pitch_rate=pitch_rate,
            max_speed_m_s=contact_speed,
            deceleration_start_distance=0.35,
            at_target_tolerance=0.025,
            at_target_speed_threshold=0.03,
            yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
        )

    def _merge_priority_goal_candidate(self, direction_world, position_world, priority, current_pos=None):
        candidate = np.asarray(position_world, dtype=np.float32).reshape(3)
        if self.detected_goal_position is None or self.detected_goal_priority is None:
            self._assign_detected_goal(direction_world, candidate)
            self.detected_goal_priority = priority
            self._clear_goal_kinematics()
            return

        stored = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3)
        current = None
        if current_pos is not None:
            current = np.asarray(current_pos, dtype=np.float32).reshape(3)
        if float(np.linalg.norm(candidate - stored)) <= self.GOAL_CANDIDATE_MATCH_DISTANCE_M:
            motion = float(np.linalg.norm(candidate - stored))
            dynamic_track = (
                motion >= self.GOAL_TRACK_PREDICT_THRESHOLD_M
                or (
                    self.detected_goal_motion_ema is not None
                    and float(self.detected_goal_motion_ema) >= self.GOAL_TRACK_PREDICT_THRESHOLD_M
                )
            )
            if current is not None:
                stored_self_dist = float(np.linalg.norm(stored - current))
                candidate_self_dist = float(np.linalg.norm(candidate - current))
                suspicious_collapse = (
                    (not dynamic_track)
                    and
                    stored_self_dist <= self.GOAL_CLOSE_TRACK_LOCK_DISTANCE_M
                    and stored_self_dist >= self.GOAL_CLOSE_TRACK_MIN_STORED_DISTANCE_M
                    and candidate_self_dist <= self.GOAL_CLOSE_TRACK_COLLAPSE_DISTANCE_M
                    and candidate_self_dist + self.GOAL_CLOSE_TRACK_COLLAPSE_DISTANCE_M < stored_self_dist
                )
                if suspicious_collapse:
                    self._update_goal_kinematics_ema(stored, candidate)
                    self.detected_goal_observation_count = min(int(self.detected_goal_observation_count), 9) + 1
                    return

            blended_candidate = candidate.copy()
            if current is not None:
                stored_self_dist = float(np.linalg.norm(stored - current))
                if stored_self_dist <= self.GOAL_CLOSE_TRACK_LOCK_DISTANCE_M:
                    blend_keep = 0.35 if dynamic_track else 0.75
                    blended_candidate = blend_keep * stored + (1.0 - blend_keep) * candidate

            blended_direction = np.asarray(direction_world, dtype=np.float32).reshape(3)
            if current is not None:
                dir_vec = blended_candidate - current
                dn = float(np.linalg.norm(dir_vec))
                if dn > 1e-6:
                    blended_direction = dir_vec / dn

            self._assign_detected_goal(blended_direction, blended_candidate)
            self._update_goal_kinematics_ema(stored, blended_candidate)
            if priority < self.detected_goal_priority:
                self.detected_goal_priority = priority
            return

        if priority < self.detected_goal_priority:
            self._assign_detected_goal(direction_world, candidate)
            self.detected_goal_priority = priority
            self._clear_goal_kinematics()

    def _fallback_goal_toward_search_center(
        self,
        observation,
        current_pos,
        initial_position,
        depth_meters,
        depth_range_near_m,
        depth_range_far_m,
        camera_fov_rad,
        start_platform_position_threshold_m,
    ):
        if self.search_area_center is None:
            return False, None, None, False, None

        expected_direction = np.asarray(self.search_area_center, dtype=np.float32).reshape(3) - np.asarray(current_pos, dtype=np.float32).reshape(3)
        expected_pixel = self._project_world_direction_to_pixel(
            observation,
            expected_direction,
            camera_fov_rad=camera_fov_rad,
        )
        if expected_pixel is None:
            return False, None, None, False, None

        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False, None, None, False, None

        H, W = depth.shape
        pr, pc = expected_pixel
        window_radius = 20
        r0 = max(1, pr - window_radius)
        r1 = min(H - 1, pr + window_radius + 1)
        c0 = max(1, pc - window_radius)
        c1 = min(W - 1, pc + window_radius + 1)
        if r1 <= r0 or c1 <= c0:
            return False, None, None, False, None

        local_range_map = maximum_filter(depth_meters, size=3, mode="nearest") - minimum_filter(depth_meters, size=3, mode="nearest")
        contrast_map = maximum_filter(depth_meters, size=7, mode="nearest") - depth_meters

        window_local_range = local_range_map[r0:r1, c0:c1]
        window_contrast = contrast_map[r0:r1, c0:c1]
        relaxed_mask = (window_local_range < 0.12) & (window_contrast > 0.08)
        strict_mask = (window_local_range < 0.08) & (window_contrast > 0.12)
        mask = strict_mask if np.any(strict_mask) else relaxed_mask
        rr, cc = np.nonzero(mask)
        if len(rr) == 0:
            return False, None, None, False, None

        rr = rr.astype(np.int32) + r0
        cc = cc.astype(np.int32) + c0
        if len(rr) > 256:
            pick = np.linspace(0, len(rr) - 1, 256).astype(np.int32)
            rr = rr[pick]
            cc = cc[pick]

        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        half_fov = camera_fov_rad / 2.0
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx

        dm = np.clip(depth_meters[rr, cc], depth_range_near_m, depth_range_far_m)
        horz = (cc.astype(np.float32) - (W - 1) / 2.0) / (W / 2.0) * half_fov
        vert = (rr.astype(np.float32) - (H - 1) / 2.0) / (H / 2.0) * half_fov
        rx = np.ones(len(rr), dtype=np.float32)
        ry = -np.tan(horz)
        rz = -np.tan(vert)
        rn = np.sqrt(rx**2 + ry**2 + rz**2)
        rn = np.maximum(rn, 1e-9)
        rx /= rn
        ry /= rn
        rz /= rn
        dx = R[0, 0] * rx + R[0, 1] * ry + R[0, 2] * rz
        dy = R[1, 0] * rx + R[1, 1] * ry + R[1, 2] * rz
        dz = R[2, 0] * rx + R[2, 1] * ry + R[2, 2] * rz
        dn = np.sqrt(dx**2 + dy**2 + dz**2)
        dn = np.maximum(dn, 1e-9)
        dx /= dn
        dy /= dn
        dz /= dn
        positions = np.stack([cur[0] + dm * dx, cur[1] + dm * dy, cur[2] + dm * dz], axis=-1)

        center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
        xy_dist = np.linalg.norm(positions[:, :2] - center[:2], axis=1)
        z_dist = np.abs(positions[:, 2] - center[2])
        max_z_dist = self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_M if bool(self.scene_is_open_like) else self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_CLUTTER_M
        z_weight = self.GOAL_SEARCH_SCORE_Z_WEIGHT_OPEN if bool(self.scene_is_open_like) else self.GOAL_SEARCH_SCORE_Z_WEIGHT_CLUTTER
        window_ok = (
            (xy_dist <= self.GOAL_SEARCH_CENTER_MAX_XY_DISTANCE_M)
            & (z_dist <= max_z_dist)
        )
        if initial_position is not None:
            start = np.asarray(initial_position, dtype=np.float32).reshape(3)
            start_dist = np.linalg.norm(positions - start, axis=1)
            window_ok &= start_dist >= start_platform_position_threshold_m
        if not np.any(window_ok):
            return False, None, None, False, None

        idxs = np.nonzero(window_ok)[0]
        candidate_scores = (
            xy_dist[idxs]
            + z_weight * z_dist[idxs]
            + 0.02 * (np.abs(rr[idxs] - pr) + np.abs(cc[idxs] - pc))
            - 0.6 * contrast_map[rr[idxs], cc[idxs]]
        )
        best_local = int(idxs[int(np.argmin(candidate_scores))])
        best_pos = positions[best_local].astype(np.float32)
        best_dir = np.array([dx[best_local], dy[best_local], dz[best_local]], dtype=np.float32)
        meta = {
            "pixel": (int(rr[best_local]), int(cc[best_local])),
            "search_score": self._goal_candidate_distance_score(best_pos),
            "priority": (
                0,
                float(candidate_scores[int(np.argmin(candidate_scores))]),
            ),
        }
        return True, best_dir, best_pos, False, meta

    def _find_goal_platform_from_depth(
        self,
        observation,
        initial_position=None,
        depth_edge_jump=None,
        depth_similarity_threshold_m=None,
        depth_range_near_m=None,
        depth_range_far_m=None,
        camera_fov_rad=None,
        goal_platform_max_height_diff_m=None,
        start_platform_position_threshold_m=5.0,
        min_component_size=None,
    ):
        if depth_edge_jump is None:
            depth_edge_jump = self.DEPTH_EDGE_JUMP
        if depth_similarity_threshold_m is None:
            depth_similarity_threshold_m = self.DEPTH_SIMILARITY_THRESHOLD_M
        if depth_range_near_m is None:
            depth_range_near_m = self.DEPTH_RANGE_NEAR_M
        if depth_range_far_m is None:
            depth_range_far_m = self.DEPTH_RANGE_FAR_M
        if camera_fov_rad is None:
            camera_fov_rad = self.CAMERA_FOV_RAD
        if goal_platform_max_height_diff_m is None:
            goal_platform_max_height_diff_m = self.GOAL_PLATFORM_MAX_HEIGHT_DIFF_M
        if min_component_size is None:
            min_component_size = self.MIN_COMPONENT_SIZE
        if not isinstance(observation, dict) or "depth" not in observation or "state" not in observation:
            return False, None, None, False, None
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False, None, None, False, None
        H, W = depth.shape
        edge = np.zeros((H, W), dtype=bool)
        edge[:-1, :] = (depth[1:, :] - depth[:-1, :]) >= depth_edge_jump
        depth_meters = 0.5 + 19.5 * depth
        visited = np.zeros_like(edge, dtype=bool)
        best_candidate = None
        best_priority = None
        current_pos = self._read_position_xyz(observation)
        roll, pitch = self._read_roll_pitch_rad(observation)
        yaw = self._read_yaw_rad(observation)
        if yaw is None:
            yaw = 0.0
        half_fov = camera_fov_rad / 2.0
        cr, sr = np.cos(roll), np.sin(roll)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cy, sy = np.cos(yaw), np.sin(yaw)
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float32)
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float32)
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float32)
        R = Rz @ Ry @ Rx

        cur_f = np.asarray(current_pos, dtype=np.float32).reshape(3)
        def _batch_pixels_to_world_xyz(pixels):
            arr = np.array(pixels, dtype=np.float32)
            prs = arr[:, 0]; pcs = arr[:, 1]
            dm = np.clip(depth_meters[prs.astype(int), pcs.astype(int)], depth_range_near_m, depth_range_far_m)
            h = (pcs - (W - 1) / 2.0) / (W / 2.0) * half_fov
            v = (prs - (H - 1) / 2.0) / (H / 2.0) * half_fov
            rx = np.ones(len(prs), dtype=np.float32)
            ry = -np.tan(h); rz = -np.tan(v)
            rn = np.sqrt(rx**2 + ry**2 + rz**2)
            rn = np.maximum(rn, 1e-9)
            rx /= rn; ry /= rn; rz /= rn
            dx = R[0, 0]*rx + R[0, 1]*ry + R[0, 2]*rz
            dy = R[1, 0]*rx + R[1, 1]*ry + R[1, 2]*rz
            dz = R[2, 0]*rx + R[2, 1]*ry + R[2, 2]*rz
            dn = np.sqrt(dx**2 + dy**2 + dz**2)
            dn = np.maximum(dn, 1e-9)
            dx /= dn; dy /= dn; dz /= dn
            return np.stack([cur_f[0] + dm*dx, cur_f[1] + dm*dy, cur_f[2] + dm*dz], axis=-1)

        def _bfs_edge_connected_component(sr, sc):
            queue = deque([(sr, sc)])
            visited[sr, sc] = True
            pixels = [(sr, sc)]
            while queue:
                r, c = queue.popleft()
                current_depth_m = depth_meters[r, c]
                for dr, dc in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < H and 0 <= nc < W and edge[nr, nc] and not visited[nr, nc]:
                        if abs(depth_meters[nr, nc] - current_depth_m) < depth_similarity_threshold_m:
                            visited[nr, nc] = True
                            queue.append((nr, nc))
                            pixels.append((nr, nc))
            if len(pixels) > 0:
                pixels_sorted = sorted(pixels, key=lambda p: p[1])
                mid = len(pixels_sorted) // 2
                best_r, best_c = pixels_sorted[mid]
                return len(pixels), (best_r, best_c), pixels
            return 0, None, []

        def _grow_similar_depth_region(edge_pixels):
            visited_expand = np.zeros((H, W), dtype=bool)
            for pr, pc in edge_pixels:
                visited_expand[pr, pc] = True
            region_pixels = list(edge_pixels)
            queue = deque(edge_pixels)
            while queue:
                r, c = queue.popleft()
                current_depth_m = depth_meters[r, c]
                for dr, dc in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < H and 0 <= nc < W and not visited_expand[nr, nc]:
                        if abs(depth_meters[nr, nc] - current_depth_m) < depth_similarity_threshold_m:
                            visited_expand[nr, nc] = True
                            queue.append((nr, nc))
                            region_pixels.append((nr, nc))
            return region_pixels

        seed_mask = edge & (~visited)
        seed_r, seed_c = np.nonzero(seed_mask)
        for idx in range(len(seed_r)):
            r, c = int(seed_r[idx]), int(seed_c[idx])
            if visited[r, c]:
                continue
            size, centroid, edge_pixels = _bfs_edge_connected_component(r, c)
            if size <= 0 or centroid is None or size <= min_component_size:
                continue
            region_pixels = _grow_similar_depth_region(edge_pixels)
            if not region_pixels:
                continue
            positions = _batch_pixels_to_world_xyz(region_pixels)
            z_vals = positions[:, 2]
            z_span = float(z_vals.max() - z_vals.min())
            if z_span > goal_platform_max_height_diff_m:
                continue
            mean_pos = positions.mean(axis=0)
            max_dist_from_mean = float(np.max(np.linalg.norm(positions - mean_pos, axis=1)))
            if max_dist_from_mean > self.GOAL_PLATFORM_MAX_EXTENT_M:
                continue
            candidate_mean_pos = np.asarray(mean_pos, dtype=np.float32).reshape(3)
            if self.search_area_center is not None:
                search_center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
                xy_dist = float(np.linalg.norm(candidate_mean_pos[:2] - search_center[:2]))
                z_dist = abs(float(candidate_mean_pos[2] - search_center[2]))
                max_z_dist = self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_M if bool(self.scene_is_open_like) else self.GOAL_SEARCH_CENTER_MAX_Z_DISTANCE_CLUTTER_M
                z_weight = self.GOAL_SEARCH_SCORE_Z_WEIGHT_OPEN if bool(self.scene_is_open_like) else self.GOAL_SEARCH_SCORE_Z_WEIGHT_CLUTTER
                inside_search_window = (
                    xy_dist <= self.GOAL_SEARCH_CENTER_MAX_XY_DISTANCE_M
                    and z_dist <= max_z_dist
                )
            else:
                xy_dist = 0.0
                z_dist = 0.0
                z_weight = self.GOAL_SEARCH_SCORE_Z_WEIGHT_OPEN if bool(self.scene_is_open_like) else self.GOAL_SEARCH_SCORE_Z_WEIGHT_CLUTTER
                inside_search_window = True

            centroid_offset = abs(float(centroid[0]) - (H - 1) * 0.5) + abs(float(centroid[1]) - (W - 1) * 0.5)
            priority_score = (
                xy_dist
                + (0.5 * z_weight * z_dist)
                + (0.02 * centroid_offset)
                + (0.2 * max_dist_from_mean)
                - (0.0005 * len(region_pixels))
            )
            priority = (
                0 if inside_search_window else 1,
                priority_score,
            )

            if best_priority is None or priority < best_priority:
                best_priority = priority
                best_candidate = {
                    "centroid": centroid,
                    "region_pixels": region_pixels,
                    "mean_pos": candidate_mean_pos.copy(),
                }

        if best_candidate is None:
            if not bool(self.scene_is_open_like):
                return False, None, None, False, None
            return self._fallback_goal_toward_search_center(
                observation,
                current_pos,
                initial_position,
                depth_meters,
                depth_range_near_m,
                depth_range_far_m,
                camera_fov_rad,
                start_platform_position_threshold_m,
            )
        best_pixel = best_candidate["centroid"]
        best_component_pixels = best_candidate["region_pixels"]
        best_mean_pos = np.asarray(best_candidate["mean_pos"], dtype=np.float32).reshape(3)
        r, c = best_pixel
        distance_to_goal = float(depth_meters[r, c])
        distance_to_goal = np.clip(distance_to_goal, depth_range_near_m, depth_range_far_m)
        # Bad pixels: depth < 0.5 m
        bad_pixels = (depth_meters < self.BAD_PIXEL_DEPTH_THRESHOLD_M)
        half_w = self.GOOD_PIXEL_WINDOW_SIZE // 2
        bad_dilated = maximum_filter(bad_pixels.astype(np.uint8), size=2*half_w+1, mode='constant', cval=0)
        good_mask = bad_dilated == 0
        if not good_mask[r, c]:
            gr, gc = np.nonzero(good_mask)
            if len(gr) > 0:
                dists = np.abs(gr - r) + np.abs(gc - c)
                best_i = int(np.argmin(dists))
                r, c = int(gr[best_i]), int(gc[best_i])
        d_norm = float(np.clip(depth[r, c], 0.0, 1.0))
        depth_m = 0.5 + 19.5 * d_norm
        depth_m = np.clip(depth_m, depth_range_near_m, depth_range_far_m)
        horz = (c - (W - 1) / 2.0) / (W / 2.0) * half_fov
        vert = (r - (H - 1) / 2.0) / (H / 2.0) * half_fov
        ray_body = np.array([1.0, -np.tan(horz), -np.tan(vert)], dtype=np.float32)
        n = np.linalg.norm(ray_body)
        if n < 1e-9:
            ray_body = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        else:
            ray_body = ray_body / n
        direction_world = (R @ ray_body).astype(np.float32)
        dn = np.linalg.norm(direction_world)
        if dn > 1e-9:
            direction_world = direction_world / dn
        cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
        position_world = best_mean_pos.copy()
        dir_vec = position_world - cur
        dn = float(np.linalg.norm(dir_vec))
        if dn > 1e-6:
            direction_world = dir_vec / dn
        is_start = False
        if initial_position is not None:
            dist_to_start_platform = float(np.linalg.norm(
                position_world - np.asarray(initial_position, dtype=np.float32).reshape(3)
            ))
            if dist_to_start_platform < start_platform_position_threshold_m:
                is_start = True
        meta = {
            "pixel": (r, c),
            "search_score": self._goal_candidate_distance_score(position_world),
            "priority": best_priority,
        }
        return True, direction_world, position_world, is_start, meta

    # ---------- State 1 helpers ----------
    def _state1_motion_limits(self):
        return dict(
            max_speed_m_s=self.MAX_SPEED_M_S,
            deceleration_start_distance=self.DECELERATION_START_DISTANCE,
            at_target_tolerance=self.AT_TARGET_TOLERANCE,
            at_target_speed_threshold=self.AT_TARGET_SPEED_THRESHOLD,
            yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
        )

    def _state1_next_search_waypoint(self):
        if self.search_area_center is None:
            return None
        center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
        if not bool(self.scene_is_open_like):
            idx = int(self.state1_search_point_index)
            self.state1_search_point_index += 1
            rng = np.random.RandomState(12345 + idx)
            pt = center.copy()
            pt[0] += rng.uniform(-self.SEARCH_AREA_RADIUS_X_M, self.SEARCH_AREA_RADIUS_X_M)
            pt[1] += rng.uniform(-self.SEARCH_AREA_RADIUS_Y_M, self.SEARCH_AREA_RADIUS_Y_M)
            if self.state1_use_elevated_search and self.state1_search_cruise_z is not None:
                pt[2] = float(self.state1_search_cruise_z)
            else:
                pt[2] = float(center[2])
            return np.asarray(pt, dtype=np.float32)
        ring_radii = (2.5, 5.0, 7.5, 9.5)
        ring_angles = (
            0.0,
            0.5 * np.pi,
            np.pi,
            1.5 * np.pi,
            0.25 * np.pi,
            0.75 * np.pi,
            1.25 * np.pi,
            1.75 * np.pi,
        )
        idx = int(self.state1_search_point_index)
        radius = ring_radii[(idx // len(ring_angles)) % len(ring_radii)]
        angle = ring_angles[idx % len(ring_angles)]
        self.state1_search_point_index += 1
        pt = center.copy()
        pt[0] += radius * np.cos(angle)
        pt[1] += radius * np.sin(angle)
        if self.state1_use_elevated_search and self.state1_search_cruise_z is not None:
            pt[2] = float(self.state1_search_cruise_z)
        else:
            pt[2] = float(center[2])
        return np.asarray(pt, dtype=np.float32)

    def _depth_suggests_open_scene(self, observation, current_pos):
        depth_median = self._depth_median_m(observation)
        if depth_median is None:
            return False
        if float(np.asarray(current_pos, dtype=np.float32).reshape(3)[2]) > self.OPEN_LIKE_MAX_START_Z_M:
            return False
        if depth_median < self.OPEN_LIKE_DEPTH_MEDIAN_M:
            return False
        if not isinstance(observation, dict) or "depth" not in observation:
            return False
        depth = np.squeeze(np.asarray(observation["depth"], dtype=np.float32))
        if depth.ndim != 2:
            return False
        depth_meters = 0.5 + 19.5 * depth
        H, W = depth_meters.shape
        r0 = max(0, H // 2 - 3)
        r1 = min(H, H // 2 + 4)
        c0 = max(0, W // 2 - 3)
        c1 = min(W, W // 2 + 4)
        if r1 <= r0 or c1 <= c0:
            return False
        center_median = float(np.median(depth_meters[r0:r1, c0:c1]))
        return center_median >= self.OPEN_LIKE_CENTER_MEDIAN_M

    def act(self, observation):
        """
        Main control tick: parse ``observation``, update the state machine, return a 5-D action.

        Parameters
        ----------
        observation : dict
            ``"state"``: ego vector (position, orientation, rates, search offset). \
            ``"depth"``: ``H×W`` normalized depth in ``[0, 1]`` (mapped to meters as ``0.5 + 19.5 * d``).

        Returns
        -------
        ndarray, shape (5,)
            ``[vx, vy, vz, speed_cmd, yaw_norm]`` in the simulator's convention.
        """
        current_pos = self._read_position_xyz(observation)
        current_velocity = self._read_velocity_xyz(observation)
        roll, pitch = self._read_roll_pitch_rad(observation)
        angular_velocity = self._read_angular_velocity(observation)
        roll_rate = float(angular_velocity[0]) if len(angular_velocity) >= 1 else None
        pitch_rate = float(angular_velocity[1]) if len(angular_velocity) >= 2 else None
        yaw = self._read_yaw_rad(observation)
        self.act_step += 1
        # print(self.state)
        if self.initial_position is None:
            self.initial_position = np.asarray(current_pos, dtype=np.float32).reshape(3).copy()
        if self.scene_is_open_like is None:
            self.scene_is_open_like = self._depth_suggests_open_scene(observation, current_pos)
        if self.search_area_center is None:
            search_area_vector = self._read_search_area_offset(observation)
            if np.linalg.norm(search_area_vector) > 0.01:
                self.search_area_center = self._world_search_center_from_offset(current_pos, search_area_vector)
                self.search_area_center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
                if self.state1_search_cruise_z is None:
                    self.state1_search_cruise_z = float(self.search_area_center[2])

        if self.state != 3:
            detected, direction_world, position_world, is_start, goal_meta = self._find_goal_platform_from_depth(
                observation,
                initial_position=self.initial_position,
                start_platform_position_threshold_m=5.0,
            )
            goal_detection_threshold = (
                self.MIN_GOAL_DETECTIONS_BEFORE_STATE3
                if bool(self.scene_is_open_like)
                else self.MIN_GOAL_DETECTIONS_BEFORE_STATE3_CLUTTER
            )
            if detected and not is_start and self._goal_in_search_bounds(position_world):
                self.goal_detection_count += 1
                pos_world = np.asarray(position_world, dtype=np.float32).reshape(3)
                priority = goal_meta["priority"] if isinstance(goal_meta, dict) and "priority" in goal_meta else None
                self._fuse_goal_observation(direction_world, pos_world, current_pos=current_pos)
                dist_to_goal = float(np.linalg.norm(pos_world - np.asarray(current_pos, dtype=np.float32).reshape(3)))
                if (
                    dist_to_goal > 0.5
                    and self.act_step >= self.MIN_STEPS_BEFORE_STATE3
                    and self.state1_danger_steps_remaining == 0
                    and self.goal_detection_count >= goal_detection_threshold
                ):
                    self.state = 3
                    if self.detected_goal_position is None:
                        self._assign_detected_goal(direction_world, pos_world)
                        self.detected_goal_priority = priority
            else:
                if bool(self.scene_is_open_like):
                    self.goal_detection_count = 0
                else:
                    self.goal_detection_count = int(self.goal_detection_count)

        if self.state == 3:
            detected, direction_world, position_world, is_start, goal_meta = self._find_goal_platform_from_depth(
                observation, initial_position=self.initial_position, start_platform_position_threshold_m=5.0
            )
            if detected and not is_start and self._goal_in_search_bounds(position_world):
                self.state3_no_goal_steps = 0
                pos_world = np.asarray(position_world, dtype=np.float32).reshape(3)
                priority = goal_meta["priority"] if isinstance(goal_meta, dict) and "priority" in goal_meta else None
                self._fuse_goal_observation(direction_world, pos_world, current_pos=current_pos)
                dist_to_goal = float(np.linalg.norm(pos_world - np.asarray(current_pos, dtype=np.float32).reshape(3)))
                if dist_to_goal > 0.5 and self.detected_goal_position is None:
                    self._assign_detected_goal(direction_world, pos_world)
                    self.detected_goal_priority = priority
            else:
                self.state3_no_goal_steps += 1

            if self.state3_no_goal_steps >= self.STATE3_NO_GOAL_LOOK_STEPS:
                hold_pos = np.asarray(current_pos, dtype=np.float32).reshape(3)
                action = self._velocity_command_toward_point(
                    current_pos, hold_pos, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate,
                    max_speed_m_s=self.MAX_SPEED_M_S,
                    deceleration_start_distance=0,  # state 3: no decel, max speed
                    at_target_tolerance=self.AT_TARGET_TOLERANCE,
                    at_target_speed_threshold=self.AT_TARGET_SPEED_THRESHOLD,
                    yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                )
                yaw_rad = self._read_yaw_rad(observation) or 0.0
                yaw_step = self.STATE2_YAW_STEP_RAD / np.pi
                action[4] = float(np.clip((yaw_rad / np.pi + yaw_step + 1) % 2 - 1, -1.0, 1.0))
                return action

            if not detected and self.detected_goal_position is not None:
                stored = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3)
                current = np.asarray(current_pos, dtype=np.float32).reshape(3)
                to_stored = stored - current
                dist_to_stored = float(np.linalg.norm(to_stored))
                if dist_to_stored <= self.STATE3_LOST_GOAL_NEAR_DISTANCE_M:
                    target = stored.copy()
                    if dist_to_stored <= 0.8:
                        target[2] -= 0.03
                        max_speed = self.STATE3_LOST_GOAL_FINAL_SPEED_M_S
                        decel_start = 0.45
                        at_target_tolerance = 0.03
                        at_target_speed_threshold = 0.03
                    else:
                        max_speed = self.STATE3_LOST_GOAL_NEAR_SPEED_M_S
                        decel_start = 0.9
                        at_target_tolerance = 0.05
                        at_target_speed_threshold = 0.05
                    return self._velocity_command_toward_point(
                        current_pos, target, current_velocity,
                        roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate,
                        max_speed_m_s=max_speed,
                        deceleration_start_distance=decel_start,
                        at_target_tolerance=at_target_tolerance,
                        at_target_speed_threshold=at_target_speed_threshold,
                        yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                    )
                reached = dist_to_stored <= self.AT_TARGET_TOLERANCE
                passed = False
                if self.detected_goal_direction is not None:
                    dir_vec = np.asarray(self.detected_goal_direction, dtype=np.float32).reshape(3)
                    dn = float(np.linalg.norm(dir_vec))
                    if dn > 1e-6:
                        dir_vec = dir_vec / dn
                        passed = float(np.dot(to_stored, dir_vec)) < -0.1
                if (reached or passed) and self.detected_goal_direction is not None:
                    dir_vec = np.asarray(self.detected_goal_direction, dtype=np.float32).reshape(3)
                    dn = float(np.linalg.norm(dir_vec))
                    if dn > 1e-6:
                        dir_vec = dir_vec / dn
                        move_target = stored + dir_vec * 10.0
                    else:
                        move_target = stored
                else:
                    move_target = stored
                action = self._velocity_command_toward_point(
                    current_pos, move_target, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate,
                    max_speed_m_s=self.MAX_SPEED_M_S,
                    deceleration_start_distance=0,
                    at_target_tolerance=self.AT_TARGET_TOLERANCE,
                    at_target_speed_threshold=self.AT_TARGET_SPEED_THRESHOLD,
                    yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                )
                return action

            dist_to_goal = float("inf")
            if self.detected_goal_position is not None:
                dist_to_goal = float(np.linalg.norm(np.asarray(current_pos, dtype=np.float32).reshape(3) - np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3)))
                if dist_to_goal < 1.5 and max(abs(roll), abs(pitch)) > self.STATE3_TILT_RECOVERY_RAD:
                    current_yaw_rad = self._read_yaw_rad(observation)
                    current_yaw = float(np.clip((current_yaw_rad if current_yaw_rad is not None else 0.0) / np.pi, -1.0, 1.0))
                    action = np.zeros(5, dtype=np.float32)
                    action[4] = current_yaw
                    return action
                if (
                    dist_to_goal < self.STATE3_TOUCHDOWN_FINAL_DISTANCE_M
                    and float(np.linalg.norm(current_velocity)) < 0.2
                ):
                    target = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3).copy()
                    target[2] = min(
                        float(np.asarray(current_pos, dtype=np.float32).reshape(3)[2]),
                        max(
                            float(target[2] - self.STATE3_TOUCHDOWN_FINAL_BIAS_M),
                            float(np.asarray(current_pos, dtype=np.float32).reshape(3)[2] - 0.1),
                        ),
                    )
                    return self._velocity_command_toward_point(
                        current_pos,
                        target,
                        current_velocity,
                        roll=roll,
                        pitch=pitch,
                        roll_rate=roll_rate,
                        pitch_rate=pitch_rate,
                        max_speed_m_s=0.08,
                        deceleration_start_distance=0.2,
                        at_target_tolerance=0.02,
                        at_target_speed_threshold=0.02,
                        yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                    )
                if dist_to_goal < 0.45:
                    target = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3).copy()
                    current_z = float(np.asarray(current_pos, dtype=np.float32).reshape(3)[2])
                    target[2] = min(
                        current_z,
                        max(float(target[2] - 0.03), current_z - 0.08),
                    )
                    return self._velocity_command_toward_point(
                        current_pos,
                        target,
                        current_velocity,
                        roll=roll,
                        pitch=pitch,
                        roll_rate=roll_rate,
                        pitch_rate=pitch_rate,
                        max_speed_m_s=0.12,
                        deceleration_start_distance=0.4,
                        at_target_tolerance=0.025,
                        at_target_speed_threshold=0.03,
                        yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                    )
                if (
                    dist_to_goal < 1.5
                    and self.detected_goal_motion_ema is not None
                    and float(self.detected_goal_motion_ema) < 0.12
                ):
                    target = np.asarray(self.detected_goal_position, dtype=np.float32).reshape(3).copy()
                    target[2] -= 0.04
                    return self._velocity_command_toward_point(
                        current_pos,
                        target,
                        current_velocity,
                        roll=roll,
                        pitch=pitch,
                        roll_rate=roll_rate,
                        pitch_rate=pitch_rate,
                        max_speed_m_s=0.18,
                        deceleration_start_distance=0.6,
                        at_target_tolerance=0.03,
                        at_target_speed_threshold=0.04,
                        yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                    )
            if dist_to_goal < 0.5:
                near_dir, = self._near_depth_bearing(observation, max_depth_m=1.0)
                if near_dir is not None:
                    dir_vec = np.asarray(near_dir, dtype=np.float32).reshape(3)
                else:
                    dir_vec = np.asarray(self.detected_goal_direction, dtype=np.float32).reshape(3) if self.detected_goal_direction is not None else None
            else:
                dir_vec = np.asarray(self.detected_goal_direction, dtype=np.float32).reshape(3) if self.detected_goal_direction is not None else None
            if dir_vec is not None:
                n = float(np.linalg.norm(dir_vec))
                if n > 1e-6:
                    dir_vec = dir_vec / n
                    current_speed = float(np.linalg.norm(current_velocity))
                    target_speed = min(self.MAX_SPEED_M_S, current_speed + self.ACCELERATION_M_S2 * self.SIM_DT)
                    angle_scale = self._approach_angle_speed_scale(current_velocity, dir_vec)
                    target_speed = target_speed * angle_scale
                    velocity = dir_vec * target_speed
                else:
                    velocity = np.asarray(current_velocity, dtype=np.float32).reshape(3)
                yaw_to_direction = None
                dir_xy_norm = float(np.sqrt(dir_vec[0]**2 + dir_vec[1]**2))
                if dir_xy_norm > 1e-6:
                    desired_yaw = float(np.arctan2(dir_vec[1], dir_vec[0]))
                    yaw_to_direction = float(np.clip(desired_yaw / np.pi, -1.0, 1.0))
                current_yaw_rad = self._read_yaw_rad(observation)
                current_yaw = float(np.clip((current_yaw_rad if current_yaw_rad is not None else 0.0) / np.pi, -1.0, 1.0))
                action = np.zeros(5, dtype=np.float32)
                action[0] = velocity[0]
                action[1] = velocity[1]
                action[2] = velocity[2]
                action[3] = float(np.linalg.norm(velocity))
                action[4] = yaw_to_direction if yaw_to_direction is not None else current_yaw
                return action

        if self.state == 0:
            if self.search_area_center is None:
                search_area_vector = self._read_search_area_offset(observation)
                if np.linalg.norm(search_area_vector) > 0.01:
                    self.search_area_center = self._world_search_center_from_offset(current_pos, search_area_vector)
                    self.search_area_center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
                    self.state1_search_cruise_z = float(self.search_area_center[2])

            if self.search_area_center is not None:
                if not self.target:
                    self.target = self._waypoints_for_height_match(
                        current_pos, self.search_area_center,
                        horizontal_m=self.HORIZONTAL_M, rise_height_m=self.RISE_HEIGHT_M,
                    )
                if self.target:
                    current_waypoint = self.target[0]
                    action = self._velocity_command_toward_point(
                        current_pos, current_waypoint, current_velocity,
                        roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate,
                        max_speed_m_s=self.MAX_SPEED_M_S,
                        deceleration_start_distance=self.DECELERATION_START_DISTANCE,
                        at_target_tolerance=self.AT_TARGET_TOLERANCE,
                        at_target_speed_threshold=self.AT_TARGET_SPEED_THRESHOLD,
                        yaw_face_direction_min_distance_m=self.YAW_FACE_DIRECTION_MIN_DISTANCE_M,
                    )
                    center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
                    to_center_xy = np.array([center[0] - current_pos[0], center[1] - current_pos[1]], dtype=np.float32)
                    horiz = float(np.linalg.norm(to_center_xy))
                    if horiz > 1e-6:
                        desired_yaw = float(np.arctan2(to_center_xy[1], to_center_xy[0]))
                        action[4] = float(np.clip(desired_yaw / np.pi, -1.0, 1.0))
                    dist = float(np.linalg.norm(np.asarray(current_waypoint, dtype=np.float32).reshape(3) - np.asarray(current_pos, dtype=np.float32).reshape(3)))
                    speed = float(np.linalg.norm(current_velocity))
                    if dist < self.AT_TARGET_TOLERANCE and speed < self.AT_TARGET_SPEED_THRESHOLD:
                        self.target.pop(0)
                        if not self.target:
                            self.target = [np.asarray(self.search_area_center, dtype=np.float32)]
                            self.state = 1
                    return action
                return np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)

        if self.state == 1:
            if self.search_area_center is None:
                return np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
            cur = np.asarray(current_pos, dtype=np.float32).reshape(3)
            center = np.asarray(self.search_area_center, dtype=np.float32).reshape(3)
            mk = self._state1_motion_limits()
            yaw_rad = yaw if yaw is not None else 0.0

            # ----- Danger zone: only when front is clear but left/right has close obstacle -----
            if self._lateral_close_obstacle_corridor_clear(observation, danger_distance_m=self.DANGER_DISTANCE_M):
                self.state1_danger_steps_remaining = self.STATE1_DANGER_STEPS_WINDOW
            if self.state1_danger_steps_remaining > 0:
                self.state1_danger_steps_remaining -= 1

            # ----- Front obstacle while going to target (or while seeking): Find open path, set detour -----
            if (
                self.target
                and not self.state1_turning_270
                and self._front_patch_obstacle_too_close(
                    observation, current_velocity, roll, pitch, yaw_rad,
                    front_obstacle_min_depth_m=self.FRONT_OBSTACLE_MIN_DEPTH_M,
                    front_patch_rows=self.FRONT_PATCH_ROWS,
                    front_patch_cols=self.FRONT_PATCH_COLS,
                    camera_fov_rad=self.CAMERA_FOV_RAD,
                )
            ):
                already_seeking = self.state1_seeking_clear_direction
                obstacle_depth_m = self._min_depth_in_velocity_front_patch(
                    observation, current_velocity, roll, pitch, yaw_rad,
                    front_patch_rows=self.FRONT_PATCH_ROWS,
                    front_patch_cols=self.FRONT_PATCH_COLS,
                    camera_fov_rad=self.CAMERA_FOV_RAD,
                )
                final_target = self.target[-1] if self.target else center
                waypoint = self._detour_waypoint_from_obstacle_cc(
                    observation, cur, final_target, obstacle_depth_m or 5.0,
                    current_velocity, roll, pitch, yaw_rad,
                    camera_fov_rad=self.CAMERA_FOV_RAD,
                    height_tolerance_m=1.0,
                    min_clear_distance_px=5,
                )
                self.state1_chosen_clear_direction = None
                if waypoint is not None and self.state1_danger_steps_remaining == 0:
                    prev_wp = np.asarray(self.target[0], dtype=np.float32).reshape(3) if self.target else cur
                    w_prev = self.DETOUR_WAYPOINT_SMOOTHING_PREV_WEIGHT
                    blended = w_prev * prev_wp + (1.0 - w_prev) * np.asarray(waypoint, dtype=np.float32).reshape(3)
                    self.target.insert(0, blended.astype(np.float32))
                    self.state1_has_detour_waypoint = True
                else:
                    to_center = center - cur
                    n = float(np.linalg.norm(to_center))
                    to_center = to_center / n if n > 1e-6 else np.array([1.0, 0.0, 0.0], dtype=np.float32)
                    chosen = self._clearest_horizontal_toward_search_center(
                        observation, to_center, top_k=5, patch_size=5, camera_fov_rad=self.CAMERA_FOV_RAD,
                        min_clear_depth_m=(obstacle_depth_m + 0.5) if obstacle_depth_m is not None else None,
                    )
                    self.state1_chosen_clear_direction = chosen
                    if chosen is not None and (self.state1_danger_steps_remaining == 0 or waypoint is None):
                        depth_m = self._depth_along_world_direction(observation, chosen, camera_fov_rad=self.CAMERA_FOV_RAD)
                        dist = min(max(0.0, (float(depth_m) - 5.0) if depth_m else 0.0), 5.0) if depth_m is not None else 1.0
                        new_wp = np.asarray(cur + dist * chosen, dtype=np.float32)
                        prev_wp = np.asarray(self.target[0], dtype=np.float32).reshape(3) if self.target else cur
                        w_prev = self.DETOUR_WAYPOINT_SMOOTHING_PREV_WEIGHT
                        blended = w_prev * prev_wp + (1.0 - w_prev) * new_wp
                        self.target.insert(0, blended.astype(np.float32))
                        self.state1_has_detour_waypoint = True
                    elif not already_seeking:
                        to_xy = to_center[:2] / (np.linalg.norm(to_center[:2]) or 1e-6)
                        look_x, look_y = float(np.cos(yaw_rad)), float(np.sin(yaw_rad))
                        self.state1_turn_direction = 1 if (-look_y * to_xy[0] + look_x * to_xy[1]) >= 0 else -1
                        self.state1_has_detour_waypoint = False
                if not already_seeking:
                    self.state1_seeking_clear_direction = True

            # ----- Going to detour (open path found); go to first waypoint -----
            if self.state1_seeking_clear_direction and self.target and self.state1_has_detour_waypoint:
                wp = np.asarray(self.target[0], dtype=np.float32).reshape(3).copy()
                # Keep current height only when using direction-based detour (chosen_clear_direction)
                if self.state1_chosen_clear_direction is not None:
                    wp[2] = cur[2]
                action = self._velocity_command_toward_point(
                    current_pos, wp, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate, **mk,
                )
                if self.state1_chosen_clear_direction is not None:
                    d = np.array([self.state1_chosen_clear_direction[0], self.state1_chosen_clear_direction[1]], dtype=np.float32)
                    if np.linalg.norm(d) > 1e-6:
                        action[4] = float(np.clip(np.arctan2(d[1], d[0]) / np.pi, -1.0, 1.0))
                if np.linalg.norm(wp - cur) < self.AT_TARGET_TOLERANCE and np.linalg.norm(current_velocity) < self.AT_TARGET_SPEED_THRESHOLD:
                    self.target.pop(0)
                    self.state1_seeking_clear_direction = False
                    self.state1_chosen_clear_direction = None
                    self.state1_has_detour_waypoint = False
                    if not self.target:
                        yaw_rad = self._read_yaw_rad(observation) or 0.0
                        self.state1_turn_270_prev_yaw = yaw_rad
                        self.state1_turn_270_swept_rad = 0.0
                        self.state1_turning_270 = True
            elif self.state1_seeking_clear_direction:
                action = self._velocity_command_toward_point(
                    current_pos, cur, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate, **mk,
                )
                yaw_rad = self._read_yaw_rad(observation) or 0.0
                turn_dir = self.state1_turn_direction if self.state1_turn_direction is not None else (1 if np.random.rand() < 0.5 else -1)
                action[4] = float(np.clip(
                    np.clip(yaw_rad / np.pi, -1.0, 1.0) + self.STATE1_TURN_YAW_STEP_NORM * turn_dir,
                    -1.0, 1.0,
                ))
                if self.state1_danger_steps_remaining == 0 and self._is_forward_center_clear_depth(observation, self.CLEAR_DIRECTION_MIN_DEPTH_M, front_patch_radius_px=self.FRONT_PATCH_RADIUS_PX):
                    look_dir = self._camera_forward_in_world(observation, camera_fov_rad=self.CAMERA_FOV_RAD)
                    if look_dir is not None:
                        depth_m = self._depth_along_world_direction(observation, look_dir, camera_fov_rad=self.CAMERA_FOV_RAD)
                        dist = min(max(0.0, (float(depth_m) - 3.0) if depth_m else 0.0), 1.0) if depth_m is not None else 1.0
                        milestone = np.asarray(cur + dist * look_dir, dtype=np.float32)
                        self.target.insert(0, milestone)
                        self.state1_has_detour_waypoint = True
                        self.state1_seeking_clear_direction = False
                return action

            if self.state1_turning_270:
                action = self._velocity_command_toward_point(
                    current_pos, cur, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate, **mk,
                )
                yaw_rad = self._read_yaw_rad(observation) or 0.0
                if self.state1_turn_270_prev_yaw is not None:
                    delta = (yaw_rad - self.state1_turn_270_prev_yaw + np.pi) % (2 * np.pi) - np.pi
                    self.state1_turn_270_swept_rad += delta / np.pi
                self.state1_turn_270_prev_yaw = yaw_rad
                action[4] = float(np.clip((yaw_rad / np.pi + self.STATE2_YAW_STEP_RAD + 1) % 2 - 1, -1.0, 1.0))
                turn_target = self.STATE1_TURN_TARGET_OPEN_RAD if bool(self.scene_is_open_like) else self.STATE1_TURN_TARGET_CLUTTER_RAD
                if self.state1_turn_270_swept_rad >= turn_target:
                    self.state1_turning_270 = False
                    self.state1_turn_270_prev_yaw = None
                    self.state1_turn_270_swept_rad = 0.0
                    next_pt = self._state1_next_search_waypoint()
                    if next_pt is not None:
                        self.target = [next_pt]
                return action

            if self.target:
                wp = np.asarray(self.target[0], dtype=np.float32).reshape(3).copy()
                if self.state1_use_elevated_search and self.state1_search_cruise_z is not None:
                    wp[2] = float(self.state1_search_cruise_z)
                else:
                    wp[2] = cur[2]
                action = self._velocity_command_toward_point(
                    current_pos, wp, current_velocity,
                    roll=roll, pitch=pitch, roll_rate=roll_rate, pitch_rate=pitch_rate, **mk,
                )
                if np.linalg.norm(wp - cur) < self.AT_TARGET_TOLERANCE and np.linalg.norm(current_velocity) < self.AT_TARGET_SPEED_THRESHOLD:
                    self.target.pop(0)
                    yaw_rad = self._read_yaw_rad(observation) or 0.0
                    self.state1_turn_270_prev_yaw = yaw_rad
                    self.state1_turn_270_swept_rad = 0.0
                    self.state1_turning_270 = True
                return action

            return np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)

        action = np.random.uniform(-1, 1, size=5)
        action[3] = np.clip(action[3], 0, 1)
        return action

    def reset(self):
        """Reset all episode-specific state. Invoked by the benchmark between seeds/maps."""
        self.state = 0
        self.target = []
        self.search_area_center = None
        self.initial_position = None
        self.detected_goal_position = None
        self.detected_goal_direction = None
        self.state1_turning_270 = False
        self.state1_turn_270_prev_yaw = None
        self.state1_turn_270_swept_rad = 0.0
        self.state1_turn_direction = None
        self.state1_seeking_clear_direction = False
        self.state1_chosen_clear_direction = None
        self.state1_has_detour_waypoint = False
        self.state1_danger_steps_remaining = 0
        self.state1_search_point_index = 0
        self.state1_use_elevated_search = False
        self.state1_search_cruise_z = None
        self.scene_is_open_like = None
        self.state3_no_goal_steps = 0
        self.act_step = 0
        self.goal_detection_count = 0
        self.detected_goal_search_score = None
        self.detected_goal_observation_count = 0
        self.detected_goal_priority = None
        self.detected_goal_motion_ema = None
        self.detected_goal_velocity = None
